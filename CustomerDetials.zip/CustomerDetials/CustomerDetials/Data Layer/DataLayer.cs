﻿using System.Data.SqlClient;
using System.Data;

namespace CustomerDetials.Data_Layer
{
    public class DataLayer
    {
        string conn = string.Empty;
        public DataLayer()
        {
            string connString = new ConfigurationBuilder().AddJsonFile("appsettings.json").Build().GetSection("ConnectionStrings")["dbcs"];
            conn = Convert.ToString(connString);
        }

        public DataTable GetDataTable(string query)
        {
            SqlCommand cmd = new SqlCommand();
            SqlConnection sqlConn = new SqlConnection();
            SqlDataAdapter dataAdapter = new SqlDataAdapter();
            DataTable dt = new DataTable();

            cmd.CommandText = query;
            sqlConn.ConnectionString = conn;
            sqlConn.Open();
            cmd.Connection = sqlConn;
            cmd.CommandType = CommandType.Text;
            dataAdapter.SelectCommand = cmd;
            dataAdapter.Fill(dt);
            sqlConn.Close();
            return dt;
        }

        public int ExecuteOnlyQuery(string query)
        {
            SqlConnection sqlConn = new SqlConnection();
            SqlCommand cmd = new SqlCommand();

            cmd.CommandText = query;
            sqlConn.ConnectionString = conn;
            sqlConn.Open();
            cmd.Connection = sqlConn;
            cmd.CommandType = CommandType.Text;
            int count = cmd.ExecuteNonQuery();
            sqlConn.Close();
            return count;
        }
    }
}
