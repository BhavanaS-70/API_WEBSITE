﻿using CustomeDetials.Models;
using System.ComponentModel.DataAnnotations;

namespace Web_API_project.Models
{
    public class BOReport
    {
        [Required]
        public string BranchName { get; set; }

        [Required]
        public string BranchCode { get; set; }

        [Required]
        public string BranchIfscCode { get; set; }

        [Required]
        public string Area { get; set; }

        [Required] 
        public int Pincode { get; set; }

        [Required]
        public string Street { get; set; }

        [Required]
        public string TalukName { get; set; }

        [Required]
        public string DistrictName { get; set; }

        
    }

    public class BOTransactionReport
    {
        [Required]
        public int TransactionID { get; set; }

        [Required]
        public string CustomerName { get; set; }

        [Required]
        public string BranchName { set; get; }

        [Required]
        public decimal Amount { get; set; }

        [Required]
        public DateTime DateOftransaction { get; set; }

        [Required]
        public string TransactionDoneBy { get; set; }

        [Required]
        public DateTime ClearDate { get; set; }
    }

}
