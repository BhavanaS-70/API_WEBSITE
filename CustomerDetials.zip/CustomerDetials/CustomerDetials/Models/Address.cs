﻿using System.ComponentModel.DataAnnotations;

namespace CustomerDetials.Models
{
    public class Address
    {
        [Required(AllowEmptyStrings = false)]
        public string Area { get; set; }

        public string Street { get; set; }

        [Required]
        public int Pincode { get; set; }
        
        public int TalukID { get; set; }

        public int DistrictID { get; set; }

        public string LandMark { get; set; }
    }
}
