﻿using CustomeDetials.Models;
using System.ComponentModel.DataAnnotations;

namespace CustomerDetials.Models
{
    public class BOCustomer:Response
    {
        public int ID { get; set; }

        [Required(AllowEmptyStrings = false)]
        [StringLength(30,ErrorMessage ="FirstName should be less than 30 Character")]
        public string FirstName { get; set; }

        [StringLength(30)]
        public string MiddleName { get; set; }

        [Required(AllowEmptyStrings = false)]
        //[StringLength(30)]
        public string LastName { get; set; }

        [Required(AllowEmptyStrings = false)]
        //[StringLength(30)]
        public string FatherName { get; set; }

        [Required(AllowEmptyStrings = false)]
        //[StringLength(30)]
        public string MotherName { get; set; }

        [Required]
        public DateTime DOB { get; set; }

        [Required(AllowEmptyStrings = false)]
        [Range(0,2)]
        public int Gender { get; set; }

        public Address TempAddress { get; set; }

        public Address PermanentAddress { get; set; }

        [Required(AllowEmptyStrings = false)]
        [Phone]
        public string MobileNumber { get; set; }

        [Required(AllowEmptyStrings = false)]
        //[]
        public string AadharNumber { get; set; }

        [Required(AllowEmptyStrings = false)]
        public string PanNumber { get; set; }

        [Required]
        [EmailAddress]
        public string EmailID { get; set; }
    }
}
