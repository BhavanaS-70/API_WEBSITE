﻿using CustomeDetials.Models;
using System.ComponentModel.DataAnnotations;

namespace CustomerDetials.Models
{
    public class BOBranch: Response
    {
        [Required]
        public int ID { get; set; }

        [Required]
        public string BranchName { get; set; }
        //4 digits
        [Required]
        public string BranchCode { get; set; }

        [Required]
        public string BranchIFSC { get; set; }

        [Required]
        public Address branchAddress { get; set; }

        [Required]
        public int BankID { get; set; }

    }
}
