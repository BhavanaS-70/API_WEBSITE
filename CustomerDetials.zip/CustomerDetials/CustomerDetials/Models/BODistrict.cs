﻿using CustomeDetials.Models;
using System.ComponentModel.DataAnnotations;

namespace CustomerDetials.Models
{
    public class BODistrict: Response
    {
        [Required]
        public int D_Id { get; set; }
        [Required]
        public string D_Name { get; set; }
    }
}
