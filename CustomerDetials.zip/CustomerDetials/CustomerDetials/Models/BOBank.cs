﻿using CustomeDetials.Models;
using System.ComponentModel.DataAnnotations;

namespace CustomerDetials.Models
{
    public class BOBank: Response
    {
        public int BankId { get; set; }
        [Required]
        public string? BankName { get; set; }
        
        public int BranchCount { get; set;}
    }
}
