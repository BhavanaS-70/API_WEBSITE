﻿using System.ComponentModel.DataAnnotations;

namespace CustomeDetials.Models
{
    public class BOTransaction: Response
    {
        [Required]
        public int Id { get; set; }

        [Required]
        public int CustID { get; set; }

        [Required]
        public int BranchID { get; set; }

        [Required]
        public decimal Amount { get; set; }

        [Required]
        public DateTime DateOfTransaction { get; set; }

        [Required]
        [StringLength(30, ErrorMessage = "Transaction customer name should be less than 30 Character")]
        public string? TrasacionDoneBy { get; set; }

        [Required]
        public DateTime ClearDate { get; set; }
    }
}
