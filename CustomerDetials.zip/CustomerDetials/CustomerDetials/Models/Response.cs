﻿namespace CustomeDetials.Models
{
    public class Response
    {
        public bool IsSuccess { get; set; }=true;

        public string? Message { get; set; }

        public int statusCode { get; set; }
    }
}
