﻿using CustomeDetials.Models;

namespace CustomerDetials.Models
{
    public class BOTaluk: Response
    {
        public int T_Id { get; set; }
        public string T_Name { get; set; } = "";
        public int D_Id { get; set; }
    }
}
