﻿using CustomeDetials.Business_Layer;
using CustomeDetials.Models;
using CustomerDetials.Business_Layer;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CustomeDetials.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransactionController : ControllerBase
    {
        List<BOTransaction> transaction = new List<BOTransaction>();
        BLTransaction blTran = new BLTransaction();

        // GET: api/<TransactionController>
        [HttpGet]
        [Route("AllTransaction")]
        public IActionResult getAllTransaction()
        {
            transaction= blTran.getAllTransaction();
            return Ok(transaction);
        }

        // GET api/<TransactionController>/5
        [HttpGet]
        [Route("SingleTransaction")]
        public IActionResult GetSingleTransaction(int id)
        {
            BOTransaction bt = blTran.getSingleTransaction(id);
            return StatusCode(bt.statusCode, bt);
        }

        // POST api/<TransactionController>
        [HttpPost]
        [Route("Insert")]
        public IActionResult SaveTransaction([FromQuery]BOTransaction blt )
        {
            BOTransaction bt = blTran.saveTransaction(blt);
            return StatusCode(bt.statusCode,bt);
        }

        // PUT api/<TransactionController>/5
        [HttpPut]
        [Route("Update")]
        public IActionResult UpdateTransaction([FromQuery]BOTransaction blt)
        {
            BOTransaction bt = blTran.updateTransaction(blt);
            return StatusCode(bt.statusCode,bt);
        }

    }
}
