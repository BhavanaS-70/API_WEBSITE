﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using CustomerDetials.Models;
using CustomerDetials.Business_Layer;
using System.Xml.Linq;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Reflection;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CustomerDetials.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        List<BOCustomer> lstCust= new List<BOCustomer>();
        BLCustomer blCust= new BLCustomer();

        // GET: api/<CustomerController>
        [HttpGet]
        [Route("AllCustomer")]
        public IActionResult GetAllCustomer()
        {
            lstCust = blCust.getAllCustomerDetials();
            //return StatusCode(lstCust, lstCust);

            return Ok(lstCust);
        }

        // GET api/<CustomerController>/5
        [HttpGet]
        [Route("SingleCustomer")]
        public IActionResult GetSingleCustomer([FromQuery]int ID)
        {
            BOCustomer cus = blCust.getSingleCustomerDetail(ID);
            return StatusCode(cus.statusCode, cus);
        }

        // POST api/<CustomerController>
        [HttpPost]
        [Route("Insert")]
        public ActionResult AddCustomerDetailrNumber([FromQuery]BOCustomer customer)
        {
            BOCustomer res=blCust.saveCustomerMasters(customer);
            return StatusCode(res.statusCode, res);
        }

        // PUT api/<CustomerController>/5
        [HttpPut]
        [Route("Update")]
        public IActionResult UpdateCustomerDetail([FromQuery] BOCustomer custObj)
        {
            BOCustomer result = blCust.UpdateCustomerDetail(custObj);
            return StatusCode(result.statusCode, result);
        }

        // DELETE api/<CustomerController>/5
        [HttpDelete]
        [Route("Delete")]
        public IActionResult DeleteCustomerDetail([FromQuery]int ID)
        {
            BLCustomer bl = new BLCustomer();
            bool result = bl.DeleteCusomerDetail(ID);
            if (result)
            {
                return result == true ? Created("", "Data Delete Successfully") : BadRequest();
            }
            return BadRequest();
        }
    }
}
