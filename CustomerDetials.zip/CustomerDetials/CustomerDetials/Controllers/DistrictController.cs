﻿using CustomerDetials.Business_Layer;
using CustomerDetials.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CustomerDetials.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DistrictController : ControllerBase
    {
        List<BODistrict> lstDist = new List<BODistrict>();
        BLDistrict blDist = new BLDistrict();
        
        [HttpGet]
        [Route("AllDistrict")]
        public IActionResult GetAllDistrict()
        {
            lstDist = blDist.getAllDistrictDetials();
            return Ok(lstDist);
        }

        [HttpGet]
        [Route("SingleDetials")]
        public IActionResult GetSingleDistrictDetial([FromQuery] int ID)
        {
            BODistrict dis = blDist.getSingleDistrictDetail(ID);
            return StatusCode(dis.statusCode,dis);
        }

        [HttpPost]
        [Route("Insert")]
        public IActionResult PostDistrictDetials([FromQuery] BODistrict bd)
        {
            BODistrict result = blDist.saveDistrictMaster(bd);
            return StatusCode(result.statusCode,result);
        }

        [HttpPut]
        [Route("Update")]
        public IActionResult PutDistrictDetials([FromQuery] BODistrict bd)
        {
            BLDistrict BLDM = new BLDistrict();
            BODistrict result = BLDM.UpdateDistrictMasterdetails(bd);
            return StatusCode(result.statusCode,result);
        }

        [HttpDelete]
        [Route("Delete")]
        public IActionResult DeleteDistrictDetial([FromQuery] int ID)
        {
            BLDistrict blDist = new BLDistrict();
            bool result = blDist.DeleteDistrictMaster(ID);
            if (result)
            {
                return result == true ? Created("", "Data was Delected") : BadRequest();
            }
            return BadRequest();
        }
    }
}
