﻿using CustomerDetials.Business_Layer;
using CustomerDetials.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CustomerDetials.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TalukController : ControllerBase
    {
        List<BOTaluk> lstTaluk = new List<BOTaluk>();
        BLTalukMaster blTaluk = new BLTalukMaster();
        
        [HttpGet]
        [Route("AllTaluk")]
        public IActionResult GetAllTaluk()
        {
            lstTaluk = blTaluk.getAllTalukDetials();
            return Ok(lstTaluk);
        }

        [HttpGet]
        [Route("SingleDetials")]
        public IActionResult GetSingleTalukDetial([FromQuery] int ID)
        {
            BOTaluk tlk = blTaluk.getSingleTalukDetail(ID);
            return StatusCode(tlk.statusCode, tlk);
        }

        [HttpPost]
        [Route("Insert")]
        public IActionResult PostTalukDetials([FromQuery] BOTaluk tk)
        {
            BOTaluk result = blTaluk.saveTalukMaster(tk);
            return StatusCode(result.statusCode, result);
        }

        [HttpPut]
        [Route("Update")]
        public IActionResult PutTalukDetials([FromQuery] BOTaluk tk)
        {
            BOTaluk result = blTaluk.UpdateTalukMasterdetails(tk);
            return StatusCode(result.statusCode,result);
        }

        [HttpDelete]
        [Route("Delete")]
        public IActionResult DeleteTalukDetial([FromQuery] int ID)
        {
            BLTalukMaster bLTaluk = new BLTalukMaster();
            bool result = bLTaluk.DeleteTalukMaster(ID);
            if (result)
            {
                return result == true ? Created("", "Data was Delected") : BadRequest();
            }
            return BadRequest();
        }
    }
}
