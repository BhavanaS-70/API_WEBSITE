﻿using CustomerDetials.Business_Layer;
using CustomerDetials.Data_Layer;
using CustomerDetials.Models;
using Microsoft.AspNetCore.Mvc;

namespace CustomerDetials.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BankController : ControllerBase
    {
        BLBank blbank = new BLBank();
        // GET api/<BankController>/5
        [HttpGet]
        [Route("SingleBank")]
        public IActionResult BankDetails(int Id)
        {
            BOBank bank = blbank.getSingleBankDetail(Id);
            return StatusCode(bank.statusCode, bank);
        }

        // POST api/<BankController>
        [HttpPost]
        [Route("InsertBank")]
        public IActionResult InsertBankDetials([FromQuery] BOBank bOBank)
        {
            BOBank result =blbank.saveBankDetail(bOBank);
            return StatusCode(result.statusCode, result);
        }

        // PUT api/<BankController>/5
        [HttpPut]
        [Route("UpdateBank")]
        public IActionResult UpdateBankDetails([FromQuery] BOBank bOBank)
        {
            BLBank bl = new BLBank();
            BOBank result = blbank.UpdateBankDetail(bOBank);
            return Ok(result);
        }
    }
}
