﻿using CustomerDetials.Business_Layer;
using CustomerDetials.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CustomeDetials.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BranchController : ControllerBase
    {
        List<BOBranch> lstBran = new List<BOBranch>();
        BLBranch blBran = new BLBranch();

        [HttpGet]
        [Route("AllBranch")]
        public IActionResult GetAllBranch()
        {
            lstBran = blBran.getAllBranchDetials();
            return Ok(lstBran);
        }

        // GET api/<BranchController>/5
        [HttpGet]
        [Route("SingleBranch")]
        public IActionResult GetSingleBranch([FromQuery] int ID)
        {
            BOBranch brh = blBran.getSingleBranchDetail(ID);
            return StatusCode(brh.statusCode, brh);
        }

        // POST api/<BranchController>
        [HttpPost]
        [Route("Insert")]
        public IActionResult AddBranchDetail([FromQuery] BOBranch branch)
        {
            BLBranch blbrh = new BLBranch();
            BOBranch result = blbrh.saveBranchDetail(branch);
            return Ok(result);
        }

        // PUT api/<BranchController>/5
        [HttpPut]
        [Route("Update")]
        public IActionResult UpdateBranchDetail([FromQuery] BOBranch branchObj)
        {
            BLBranch blbran = new BLBranch();
            BOBranch result = blBran.UpdateBranchDetail(branchObj);
            return Ok(result);
        }

        // DELETE api/<BranchController>/5
        [HttpDelete]
        [Route("Delete")]
        public IActionResult DeleteBranchDetail([FromQuery] int ID)
        {
            BLBranch blbranch = new BLBranch();
            bool result = blbranch.DeleteBranchDetail(ID);
            if (result)
            {
                return result == true ? Created("", "Data Delete Successfully") : BadRequest();
            }
            return BadRequest();
        }
    }
}
