﻿using CustomerDetials.Business_Layer;
using CustomerDetials.Models;
using Microsoft.AspNetCore.Mvc;
using Web_API_project.Business_Layer;
using Web_API_project.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Web_API_project.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReportController : ControllerBase
    {
        #region Branch
        List<BOReport> reportList = new List<BOReport>();
        BLReport blrep = new BLReport();

        // GET: api/<ReportController>
        [HttpGet]
        [Route("ALLBranch")]
        public IActionResult GetAllBranch()
        {
            reportList= blrep.getAllReport();
            return Ok(reportList);
        }
        
        [HttpGet]
        [Route("AllBranchTaluk")]
        public IActionResult BasedOnBranchTalukName()
        {
            reportList = blrep.getAllReportbasedOnTalukName();
            return Ok(reportList);
        }

        [HttpGet]
        [Route("AllBranchTalukName")]
        public IActionResult BasedOnBranchTalukName([FromQuery] string TalukName)
        {
            reportList = blrep.getSpecificTalukName(TalukName);
            return Ok(reportList);
        }

        [HttpGet]
        [Route("AllBranchDistrict")]
        public IActionResult BasedOnBranchDistrictName()
        {
            reportList = blrep.getAllReportbasedOnDisrictName();
            return Ok(reportList);
        }

        [HttpGet]
        [Route("AllBranchDistrictName")]
        public IActionResult BasedOnBranchDistrictName([FromQuery] string DistrictName)
        {
            reportList = blrep.getSpecificDistrictName(DistrictName);
            return Ok(reportList);
        }

        [HttpGet]
        [Route("BasedOnBranchPincode")]
        public IActionResult BasedOnBranchPincode()
        {
            reportList = blrep.getAllReportbasedOnPincode();
            return Ok(reportList);
        }

        [HttpGet]
        [Route("SpecificBranchPincode")]
        public IActionResult GetSpecificBranchPincode([FromQuery] int Pincode)
        {
            reportList = blrep.getSpecificPincode(Pincode);
            return Ok(reportList);
        }
        #endregion

        #region Transaction
        List<BOTransactionReport> transRep = new List<BOTransactionReport>();

        // GET: api/<ReportController>
        [HttpGet]
        [Route("ALLTransaction")]
        public IActionResult GetAllTransaction()
        {
            transRep = blrep.getAllTransactionReport();
            return Ok(transRep);
        }

        [HttpGet]
        [Route("BasedOnCustomerName")]
        public IActionResult GetAllCustomerTransaction()
        {
            transRep = blrep.getAllReportbasedOnCustomerName();
            return Ok(transRep);
        }

        [HttpGet]
        [Route("SpecificCustomerName")]
        public IActionResult GetSpecificCustomerTransaction([FromQuery]string customerName)
        {
            transRep = blrep.getSpecificCustomerName(customerName);
            return Ok(transRep);
        }

        [HttpGet]
        [Route("BasedOnBranchName")]
        public IActionResult GetAllBranchTransaction()
        {
            transRep = blrep.getAllReportbasedOnBranchName();
            return Ok(transRep);
        }

        [HttpGet]
        [Route("SpecificBranchName")]
        public IActionResult GetAllTransaction([FromQuery]string BranchName)
        {
            transRep = blrep.getSpecificBranchName(BranchName);
            return Ok(transRep);
        }

        [HttpGet]
        [Route("BasedOnAmount")]
        public IActionResult GetAllTransactionAmount()
        {
            transRep = blrep.getAllReportbasedOnAmount();
            return Ok(transRep);
        }

        [HttpGet]
        [Route("SpecificAmount")]
        public IActionResult GetSpecificTransactionAmount([FromQuery]decimal Amount)
        {
            transRep = blrep.getSpecificAmount(Amount);
            return Ok(transRep);
        }

        [HttpGet]
        [Route("MaximumTransactionLimit")]
        public IActionResult GetSpecificTransactionAmountGreater([FromQuery] decimal Amount)
        {
            transRep = blrep.getAllAmountGreat(Amount);
            return Ok(transRep);
        }

        [HttpGet]
        [Route("MinimumTransactionLimit")]
        public IActionResult GetAmountless([FromQuery] decimal Amount)
        {
            transRep = blrep.getSpecificAmountLess(Amount);
            return Ok(transRep);
        }

        [HttpGet]
        [Route("MatchingTransactionAmount")]
        public IActionResult GetTransactionAmount([FromQuery] decimal Amount)
        {
            transRep = blrep.getSpecificAmountEqual(Amount);
            return Ok(transRep);
        }

        #endregion
    }
}
