﻿using CustomerDetials.Data_Layer;
using CustomerDetials.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Reflection.Emit;
using System.Reflection;
using System.Text.RegularExpressions;

namespace CustomerDetials.Business_Layer
{
    public class BLBank
    {
        #region Delaration
        string sqlQuery = string.Empty;
        BOBank bk = new BOBank();
        DataLayer dbObj = new DataLayer();
        #endregion

        /// <summary>
        /// In this method, I am Display a single bank data
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public BOBank getSingleBankDetail([FromQuery] int Id)
        {
            
            sqlQuery = "select * from BankMaster where BANKID=" + Id + "";
            DataTable dt = dbObj.GetDataTable(sqlQuery);
            if (dt.Rows.Count > 0)
            {

                bk.BankId = (int)dt.Rows[0]["BankID"];
                bk.BankName = (string)dt.Rows[0]["BA_Name"];
                bk.BranchCount = (int)dt.Rows[0]["BranchCount"];
            }
            //In this, we are checking whether the Data found or not
            if (bk.BankId == 0)
            {
                bk.IsSuccess = false;
                bk.Message = "Data not Found";
                bk.statusCode = StatusCodes.Status404NotFound;
                return bk;
            }
            else
            {
                bk.IsSuccess = true;
                bk.Message = "Data Found";
                bk.statusCode = StatusCodes.Status200OK;
                return bk;
            }
            
        }
        
        /// <summary>
        /// In this method, I am Insert the data of Bank
        /// </summary>
        /// <param name="bankobj"></param>
        /// <returns></returns>
        public BOBank saveBankDetail(BOBank bankobj)
        {

            sqlQuery = "INSERT INTO BankMaster VALUES ('" +
                   bankobj.BankName + "', '" +
                   bankobj.BranchCount + "')";
            DataLayer dt = new DataLayer();
            int result = dt.ExecuteOnlyQuery(sqlQuery);

            //In this, we are checking whether the insertion was successful or failed
            if (result > 0)
            {
                bankobj.IsSuccess = true;
                bankobj.Message = "Inserted Successfully";
                bankobj.statusCode = StatusCodes.Status200OK;
                return bankobj;
            }
            else
            {
                bankobj.IsSuccess = false;
                bankobj.Message = "Inserted Failure";
                bankobj.statusCode = StatusCodes.Status500InternalServerError;
                return bankobj;
            }
        }
        
        /// <summary>
        /// In this method, I am update the data of Bank
        /// </summary>
        /// <param name="Obj"></param>
        /// <returns></returns>
        public BOBank UpdateBankDetail([FromQuery] BOBank Obj)
        {
            sqlQuery = "UPDATE BankMaster SET BA_Name = '" + Obj.BankName + "', BranchCount = '" + Obj.BranchCount + "' WHERE BANKID = " + Obj.BankId;

            DataLayer dt = new DataLayer();
            int result = dt.ExecuteOnlyQuery(sqlQuery);

            //In this, we are checking whether the Updation was successful or failed
            if(result > 0)
            {
                Obj.IsSuccess = true;
                Obj.Message = "Updated Successfully";
                Obj.statusCode = StatusCodes.Status200OK;
                return Obj;
            }
            else
            {
                Obj.IsSuccess = false;
                Obj.Message = "Updated Failure";
                Obj.statusCode = StatusCodes.Status500InternalServerError;
                return Obj;
            }
        }
    }
}