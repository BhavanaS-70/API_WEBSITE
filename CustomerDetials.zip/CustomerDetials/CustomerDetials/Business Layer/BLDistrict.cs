﻿using CustomerDetials.Data_Layer;
using CustomerDetials.Models;
using System.Data;

namespace CustomerDetials.Business_Layer
{
    public class BLDistrict
    {
        #region Delaration
        string sqlQuery = string.Empty;
        BODistrict dis = new BODistrict();
        List<BODistrict> district = new List<BODistrict>();
        DataLayer dbObj = new DataLayer();
        #endregion

        #region Business public methods
        /// <summary>
        /// It Will Display all District details in this method
        /// </summary>
        /// <returns></returns>
        public List<BODistrict> getAllDistrictDetials()
        {
            List<BOTaluk> lstTalukMaster = new List<BOTaluk>();
            sqlQuery = "select * from DistrictMaster";

            DataTable dt = dbObj.GetDataTable(sqlQuery);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                BODistrict dk = new BODistrict();
                dk.D_Id = (int)dt.Rows[i]["DIST_ID"];
                dk.D_Name = (string)dt.Rows[i]["DIST_NAME"];
                district.Add(dk);
            }
            return district;
        }
        
        /// <summary>
        /// It will display only single District detials in this method
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public BODistrict getSingleDistrictDetail(int ID)
        {
            sqlQuery = "select * from DistrictMaster where DIST_ID=" + ID + "";
            DataTable dt = dbObj.GetDataTable(sqlQuery);

            //In this, we are inserting and checking whether the Data found or not
            if (dt.Rows.Count > 0)
            {
                dis.D_Id = (int)dt.Rows[0]["DIST_ID"];
                dis.D_Name = (string)dt.Rows[0]["DIST_NAME"];
                dis.IsSuccess = true;
                dis.Message = "Data found";
                dis.statusCode = StatusCodes.Status200OK;
            }
            else
            {
                dis.IsSuccess = false;
                dis.Message = "Data Not found";
                dis.statusCode = StatusCodes.Status404NotFound;
            }
            return dis;
        }

        /// <summary>
        /// In this method we wan to Insert the District Master Table
        /// </summary>
        /// <param name="bd"></param>
        /// <returns></returns>
        public BODistrict saveDistrictMaster(BODistrict bd)
        {
            sqlQuery = "Insert into DistrictMaster values('" + bd.D_Name + "')";
            DataLayer dt = new DataLayer();
            int result = dt.ExecuteOnlyQuery(sqlQuery);

            //In this, we are checking whether the insertion was successful or failed
            if (result > 0)
            {
                bd.IsSuccess= true;
                bd.Message = "Inserted succesfully";
                bd.statusCode = StatusCodes.Status200OK;
                return bd;
            }
            else
            {
                bd.IsSuccess = false;
                bd.Message = "Insert Failure";
                bd.statusCode= StatusCodes.Status500InternalServerError;
                return bd;
            }
        }

        /// <summary>
        /// In this method we will Update the District Detials
        /// </summary>
        /// <param name="bd"></param>
        /// <returns></returns>
        public BODistrict UpdateDistrictMasterdetails(BODistrict bd)
        {
            sqlQuery = "Update DistrictMaster set DIST_NAME = '" + bd.D_Name  + "' where DIST_ID = " + bd.D_Id + "";
            DataLayer dBDistrictMaster = new DataLayer();
            int result = dBDistrictMaster.ExecuteOnlyQuery(sqlQuery);

            //In this, we are checking whether the Update was successful or failed
            if (result > 0)
            {
                bd.IsSuccess = true;
                bd.Message = "Updated succesfully";
                bd.statusCode = StatusCodes.Status200OK;
                return bd;
            }
            else
            {
                bd.IsSuccess = false;
                bd.Message = "Update Failure";
                bd.statusCode = StatusCodes.Status500InternalServerError;
                return bd;
            }
        }
        
        /// <summary>
        /// In this method we will Delete the Record from the District Detial
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public bool DeleteDistrictMaster(int ID)
        {
            sqlQuery = "delete from DistrictMaster where DIST_ID='" + ID + "'";
            int count = dbObj.ExecuteOnlyQuery(sqlQuery);
            return (count > 0 ? true : false);
        }
        #endregion
    }
}
