﻿using CustomerDetials.Data_Layer;
using CustomerDetials.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data;

namespace CustomerDetials.Business_Layer
{
    public class BLTalukMaster
    {
        #region Delaration
        string sqlQuery = string.Empty;
        BOTaluk tlk = new BOTaluk();
        List<BOTaluk> taluk = new List<BOTaluk>();
        DataLayer dbObj = new DataLayer();
        #endregion

        #region Business public methods
        /// <summary>
        /// It Will Display all Taluk details in this method
        /// </summary>
        /// <returns></returns>
        public List<BOTaluk> getAllTalukDetials()
        {
            List<BOTaluk> lstTalukMaster = new List<BOTaluk>();
            sqlQuery = "SELECT * FROM TalukMaster";

            DataTable dt = dbObj.GetDataTable(sqlQuery);
            BLTalukMaster bLTaluk = new BLTalukMaster();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                BOTaluk tk = new BOTaluk();
                tk.T_Id = (int)dt.Rows[i]["TALUK_ID"];
                tk.T_Name = (string)dt.Rows[i]["TALUK_Name"];
                tk.D_Id = (int)dt.Rows[1]["DIST_ID"];
                taluk.Add(tk);
            }
            return taluk;
        }

        /// <summary>
        /// It will display only single Taluk detials in this method
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public BOTaluk getSingleTalukDetail(int ID)
        {
            sqlQuery = "SELECT * FROM TalukMaster WHERE TALUK_ID=" + ID + "";
            DataTable dt = dbObj.GetDataTable(sqlQuery);

            //In this, we are inserting and checking whether the Data found or not
            if (dt.Rows.Count > 0)
            {
                tlk.T_Id = (int)dt.Rows[0]["TALUK_ID"];
                tlk.T_Name = (string)dt.Rows[0]["TALUK_Name"];
                tlk.D_Id = (int)dt.Rows[0]["DIST_ID"];
                tlk.IsSuccess = true;
                tlk.Message = "Data Found";
                tlk.statusCode = StatusCodes.Status200OK;
                return tlk;
            }
            else
            {
                tlk.IsSuccess= false;
                tlk.Message = "Data Not found";
                tlk.statusCode = StatusCodes.Status404NotFound;
                return tlk;
            }
            
        }

        /// <summary>
        /// In this method we wan to Insert the Taluk Master Table
        /// </summary>
        /// <param name="tk"></param>
        /// <returns></returns>
        public BOTaluk saveTalukMaster(BOTaluk tk)
        {
            sqlQuery = "Insert into TalukMaster values('" + tk.T_Name + "'," + tk.D_Id + ")";
            DataLayer dt = new DataLayer();
            int result = dt.ExecuteOnlyQuery(sqlQuery);

            //In this, we are checking whether the insertion was successful or failed
            if (!(result == 0))
            {
                tk.IsSuccess = true ;
                tk.Message = "Inserted Succesfully";
                tk.statusCode = StatusCodes.Status200OK;
                return tk;
            }
            else
            {
                tk.IsSuccess= false;
                tk.Message = "Insert Failure";
                tk.statusCode = StatusCodes.Status500InternalServerError;
                return tk;
            }
        }

        /// <summary>
        /// In this method we will Update the Taluk Detials
        /// </summary>
        /// <param name="tk"></param>
        /// <returns></returns>
        public BOTaluk UpdateTalukMasterdetails([FromQuery]BOTaluk tk)
        {
            string query = "Update TalukMaster set TALUK_NAME = '" + tk.T_Name + "',DIST_Id = " + tk.D_Id + " where TALUK_ID = " + tk.T_Id + "";
            DataLayer dBTalukMaster = new DataLayer();
            int result = dBTalukMaster.ExecuteOnlyQuery(query);

            //In this, we are checking whether the Update was successful or failed
            if (!(result == 0))
            {
                tk.IsSuccess = true;
                tk.Message = "Updated Succesfully";
                tk.statusCode = StatusCodes.Status200OK;
                return tk;
            }
            else
            {
                tk.IsSuccess = false;
                tk.Message = "Update Failure";
                tk.statusCode = StatusCodes.Status500InternalServerError;
                return tk;
            }
        }
        
        /// <summary>
        /// In this method we will Delete the Record from the Taluk Detial
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public bool DeleteTalukMaster([FromQuery]int ID)
        {
            sqlQuery = "delete from TalukMaster where TALUK_ID='" + ID + "'";
            int count = dbObj.ExecuteOnlyQuery(sqlQuery);
            return (count > 0 ? true : false);
        }
        #endregion
    }
}
