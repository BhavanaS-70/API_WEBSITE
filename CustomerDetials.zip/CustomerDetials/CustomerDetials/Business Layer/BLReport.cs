﻿using CustomerDetials.Business_Layer;
using CustomerDetials.Data_Layer;
using CustomerDetials.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.IO;
using System.Threading.Tasks;
using System.Xml.Linq;
using Web_API_project.Models;

namespace Web_API_project.Business_Layer
{
    public class BLReport
    {

        #region Decalration
        string sqlQuery = string.Empty;
        BOReport br = new BOReport();
        DataLayer dbObj = new DataLayer();
        #endregion

        #region Branch Class
        /// <summary>
        /// In this method, we are reterving All Reports
        /// </summary>
        /// <returns></returns>
        public List<BOReport> getAllReport()
        {
            List<BOReport> lstrep = new List<BOReport>();

            sqlQuery = "SELECT bm.BR_NAME AS [Branch Name],bm.BR_CODE AS [Branch Code],bm.BR_IFSC AS [Branch IFSC],bm.BR_AREA AS [Branch Area],bm.BR_STREET AS [Branch Street],bm.BR_PINCODE AS [Branch Pincode],tm.TALUK_NAME AS [Taluk Name]," +
                "dm.DIST_NAME AS [District Name] FROM AIR.dbo.BranchMaster bm INNER JOIN AIR.dbo.TalukMaster tm ON tm.TALUK_ID = bm.BR_TALUKID INNER JOIN AIR.dbo.DistrictMaster dm ON dm.DIST_ID = bm.BR_DISTRICTID";
            DataTable dt = dbObj.GetDataTable(sqlQuery);

            for(int i=0; i<dt.Rows.Count;i++)
            {
                //In this method, we are accessing the private method.
                lstrep.Add(lstReport(dt.Rows[i]));
            }
            return lstrep;
        }

        /// <summary>
        /// In this method, we are reterving all reports based on Taluk Name
        /// </summary>
        /// <returns></returns>
        public List<BOReport> getAllReportbasedOnTalukName()
        {
            List<BOReport> lstrep = new List<BOReport>();

            sqlQuery = "SELECT bm.BR_NAME AS [Branch Name],bm.BR_CODE AS [Branch Code],bm.BR_IFSC AS [Branch IFSC],bm.BR_AREA AS [Branch Area],bm.BR_STREET AS [Branch Street],bm.BR_PINCODE AS [Branch Pincode],tm.TALUK_NAME AS [Taluk Name]," +
                "dm.DIST_NAME AS [District Name] FROM AIR.dbo.BranchMaster bm INNER JOIN AIR.dbo.TalukMaster tm ON tm.TALUK_ID = bm.BR_TALUKID INNER JOIN AIR.dbo.DistrictMaster dm ON dm.DIST_ID = bm.BR_DISTRICTID ORDER BY tm.TALUK_NAME";
            DataTable dt = dbObj.GetDataTable(sqlQuery);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //In this method, we are accessing the private method.
                lstrep.Add(lstReport(dt.Rows[i]));
            }
            return lstrep;
        }

        /// <summary>
        /// In this method, we are reterving the specific taluk name 
        /// </summary>
        /// <param name="TalukName"></param>
        /// <returns></returns>
        public List<BOReport> getSpecificTalukName(string TalukName)
        {
            List<BOReport> lstrep = new List<BOReport>();
            //string tal = "'%" + TalukName + "%'";

            sqlQuery = "SELECT bm.BR_NAME AS [Branch Name],bm.BR_CODE AS [Branch Code],bm.BR_IFSC AS [Branch IFSC],bm.BR_AREA AS [Branch Area],bm.BR_STREET AS [Branch Street],bm.BR_PINCODE AS [Branch Pincode],tm.TALUK_NAME AS [Taluk Name]," +
                "dm.DIST_NAME AS [District Name] FROM BranchMaster bm INNER JOIN TalukMaster tm ON tm.TALUK_ID = bm.BR_TALUKID INNER JOIN DistrictMaster dm ON dm.DIST_ID = bm.BR_DISTRICTID Where tm.TALUK_NAME LIKE '%" + TalukName+"%'";
            DataTable dt = dbObj.GetDataTable(sqlQuery);
            
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //In this method, we are accessing the private method.
                lstrep.Add(lstReport(dt.Rows[i]));
            }
            return lstrep;
        }

        /// <summary>
        /// In this method, we are reterving all the report based on District name
        /// </summary>
        /// <returns></returns>
        public List<BOReport> getAllReportbasedOnDisrictName()
        {
            List<BOReport> lstrep = new List<BOReport>();
            
            sqlQuery = "SELECT bm.BR_NAME AS [Branch Name],bm.BR_CODE AS [Branch Code],bm.BR_IFSC AS [Branch IFSC],bm.BR_AREA AS [Branch Area],bm.BR_STREET AS [Branch Street],bm.BR_PINCODE AS [Branch Pincode],tm.TALUK_NAME AS [Taluk Name]," +
                "dm.DIST_NAME AS [District Name] FROM AIR.dbo.BranchMaster bm INNER JOIN AIR.dbo.TalukMaster tm ON tm.TALUK_ID = bm.BR_TALUKID INNER JOIN AIR.dbo.DistrictMaster dm ON dm.DIST_ID = bm.BR_DISTRICTID ORDER BY dm.DIST_NAME";
            DataTable dt = dbObj.GetDataTable(sqlQuery);
            
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //In this method, we are accessing the private method.
                lstrep.Add(lstReport(dt.Rows[i]));
            }
            return lstrep;
        }

        /// <summary>
        /// In this method, we are reterving the data report on District name
        /// </summary>
        /// <param name="DistrictName"></param>
        /// <returns></returns>
        public List<BOReport> getSpecificDistrictName(string DistrictName)
        {
            List<BOReport> lstrep = new List<BOReport>();
            //string dst = "'%" + DistrictName + "%'";

            sqlQuery = "SELECT bm.BR_NAME AS [Branch Name],bm.BR_CODE AS [Branch Code],bm.BR_IFSC AS [Branch IFSC],bm.BR_AREA AS [Branch Area],bm.BR_STREET AS [Branch Street],bm.BR_PINCODE AS [Branch Pincode],tm.TALUK_NAME AS [Taluk Name]," +
                "dm.DIST_NAME AS [District Name] FROM BranchMaster bm INNER JOIN TalukMaster tm ON tm.TALUK_ID = bm.BR_TALUKID INNER JOIN DistrictMaster dm ON dm.DIST_ID = bm.BR_DISTRICTID Where dm.DIST_NAME LIKE '%"+DistrictName+"%'"  /*dst "'%" + DistrictName + "%'"*/;
            DataTable dt = dbObj.GetDataTable(sqlQuery);
            
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //In this method, we are accessing the private method.
                lstrep.Add(lstReport(dt.Rows[i]));
            }
            return lstrep;
        }

        /// <summary>
        /// In this method, we are reterving all report based on pincode
        /// </summary>
        /// <returns></returns>
        public List<BOReport> getAllReportbasedOnPincode()
        {
            List<BOReport> lstrep = new List<BOReport>();
            
            sqlQuery = "SELECT bm.BR_NAME AS [Branch Name],bm.BR_CODE AS [Branch Code],bm.BR_IFSC AS [Branch IFSC],bm.BR_AREA AS [Branch Area],bm.BR_STREET AS [Branch Street],bm.BR_PINCODE AS [Branch Pincode],tm.TALUK_NAME AS [Taluk Name]," +
                "dm.DIST_NAME AS [District Name] FROM AIR.dbo.BranchMaster bm INNER JOIN AIR.dbo.TalukMaster tm ON tm.TALUK_ID = bm.BR_TALUKID INNER JOIN AIR.dbo.DistrictMaster dm ON dm.DIST_ID = bm.BR_DISTRICTID ORDER BY bm.BR_PINCODE";
            DataTable dt = dbObj.GetDataTable(sqlQuery);
            
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //In this method, we are accessing the private method.
                lstrep.Add(lstReport(dt.Rows[i]));
            }
            return lstrep;
        }

        /// <summary>
        /// In this method, we are reterving specific report based on Pincode
        /// </summary>
        /// <param name="Pincode"></param>
        /// <returns></returns>
        public List<BOReport> getSpecificPincode(int Pincode)
        {
            List<BOReport> lstrep = new List<BOReport>();
            
            sqlQuery = "SELECT bm.BR_NAME AS [Branch Name],bm.BR_CODE AS [Branch Code],bm.BR_IFSC AS [Branch IFSC],bm.BR_AREA AS [Branch Area],bm.BR_STREET AS [Branch Street],bm.BR_PINCODE AS [Branch Pincode],tm.TALUK_NAME AS [Taluk Name]," +
                "dm.DIST_NAME AS [District Name] FROM AIR.dbo.BranchMaster bm INNER JOIN AIR.dbo.TalukMaster tm ON tm.TALUK_ID = bm.BR_TALUKID INNER JOIN AIR.dbo.DistrictMaster dm ON dm.DIST_ID = bm.BR_DISTRICTID WHERE bm.BR_PINCODE LIKE '%"+Pincode+"%'";
            DataTable dt = dbObj.GetDataTable(sqlQuery);
            
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //In this method, we are accessing the private method.
                lstrep.Add(lstReport(dt.Rows[i]));
            }
            return lstrep;
        }

        /// <summary>
        /// This is the private method to accessing the Report values.
        /// </summary>
        /// <param name="brow"></param>
        /// <returns></returns>
        public BOReport lstReport(DataRow brow)
        {
            BOReport brp = new BOReport();
            brp.BranchName = (string)brow["Branch Name"];
            brp.BranchCode = (string)brow["Branch Code"];
            brp.BranchIfscCode = (string)brow["Branch IFSC"];
            brp.Area = (string)brow["Branch Area"];
            brp.Street = (string)brow["Branch Street"];
            brp.Pincode = (int)brow["Branch pincode"];
            brp.TalukName = (string)brow["Taluk Name"];
            brp.DistrictName = (string)brow["District Name"];
            return brp;
        }
        #endregion

        #region Customer Class

        #endregion

        #region Transaction class

        /// <summary>
        /// In this method, we are reterving All Reports
        /// </summary>
        /// <returns></returns>
        public List<BOTransactionReport> getAllTransactionReport()
        {
            List<BOTransactionReport> lstrep = new List<BOTransactionReport>();

            sqlQuery = "SELECT tm.TRANS_ID AS [Transaction ID],cm.FirstName + ' ' + cm.LastName AS [Customer Name],bm.BR_NAME AS [Branch Name], " +
                        "tm.AMOUNT AS [Amount],tm.DATEOFTRANSACTION AS [Date of Transaction], tm.TRANS_DONEBY AS [Payee], tm.CLEAR_DATE AS [Transaction Cleared]  " +
                        "FROM AIR.dbo.TransactionMaster1 tm INNER JOIN AIR.dbo.CustomerMaster cm ON cm.ID = tm.CUST_ID " +
                        "INNER JOIN air.dbo.BranchMaster bm ON bm.BR_ID = tm.BRANCH_ID ";
            DataTable dt = dbObj.GetDataTable(sqlQuery);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //In this method, we are accessing the private method.
                lstrep.Add(lstTransactionReport(dt.Rows[i]));
            }
            return lstrep;
        }

        /// <summary>
        /// In this method, we are reterving all reports based on Customer Name
        /// </summary>
        /// <returns></returns>
        public List<BOTransactionReport> getAllReportbasedOnCustomerName()
        {
            List<BOTransactionReport> lstrep = new List<BOTransactionReport>();

            sqlQuery = "SELECT tm.TRANS_ID AS [Transaction ID],cm.FirstName + ' ' + cm.LastName AS [Customer Name],bm.BR_NAME AS [Branch Name], tm.AMOUNT AS [Amount]," +
                        "tm.DATEOFTRANSACTION AS [Date of Transaction], tm.TRANS_DONEBY AS [Payee], tm.CLEAR_DATE AS [Transaction Cleared]  FROM AIR.dbo.TransactionMaster1 tm " +
                        "INNER JOIN AIR.dbo.CustomerMaster cm ON cm.ID = tm.CUST_ID INNER JOIN air.dbo.BranchMaster bm ON bm.BR_ID = tm.BRANCH_ID ORDER BY cm.FirstName+''+cm.LastName";
            DataTable dt = dbObj.GetDataTable(sqlQuery);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //In this method, we are accessing the private method.
                lstrep.Add(lstTransactionReport(dt.Rows[i]));
            }
            return lstrep;
        }

        /// <summary>
        /// In this method, we are reterving the specific Customer ID 
        /// </summary>
        /// <param name="CustName"></param>
        /// <returns></returns>
        public List<BOTransactionReport> getSpecificCustomerName(string CustName)
        {
            List<BOTransactionReport> lstrep = new List<BOTransactionReport>();

            sqlQuery = " SELECT tm.TRANS_ID AS [Transaction ID],cm.FirstName + ' ' + cm.LastName AS [Customer Name],bm.BR_NAME AS [Branch Name], " +
                        "tm.AMOUNT AS [Amount],tm.DATEOFTRANSACTION AS [Date of Transaction], tm.TRANS_DONEBY AS [Payee], tm.CLEAR_DATE AS [Transaction Cleared]  " +
                        "FROM AIR.dbo.TransactionMaster1 tm INNER JOIN AIR.dbo.CustomerMaster cm ON cm.ID = tm.CUST_ID INNER JOIN air.dbo.BranchMaster bm ON " +
                        "bm.BR_ID = tm.BRANCH_ID  Where cm.FirstName+''+cm.LastName LIKE '%" + CustName + "%'";
            DataTable dt = dbObj.GetDataTable(sqlQuery);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //In this method, we are accessing the private method.
                lstrep.Add(lstTransactionReport(dt.Rows[i]));
            }
            return lstrep;
        }

        /// <summary>
        /// In this method, we are reterving all the report based on Branch Name
        /// </summary>
        /// <returns></returns>
        public List<BOTransactionReport> getAllReportbasedOnBranchName()
        {
            List<BOTransactionReport> lstrep = new List<BOTransactionReport>();

            sqlQuery = "SELECT tm.TRANS_ID AS [Transaction ID],cm.FirstName + ' ' + cm.LastName AS [Customer Name],bm.BR_NAME AS [Branch Name], tm.AMOUNT AS [Amount]," +
                        "tm.DATEOFTRANSACTION AS [Date of Transaction], tm.TRANS_DONEBY AS [Payee], tm.CLEAR_DATE AS [Transaction Cleared]  FROM AIR.dbo.TransactionMaster1 tm " +
                        "INNER JOIN AIR.dbo.CustomerMaster cm ON cm.ID = tm.CUST_ID INNER JOIN air.dbo.BranchMaster bm ON bm.BR_ID = tm.BRANCH_ID ORDER BY bm.BR_NAME";
            DataTable dt = dbObj.GetDataTable(sqlQuery);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //In this method, we are accessing the private method.
                lstrep.Add(lstTransactionReport(dt.Rows[i]));
            }
            return lstrep;
        }

        /// <summary>
        /// In this method, we are reterving the data report on Specific Branch Name
        /// </summary>
        /// <param name="BranchName"></param>
        /// <returns></returns>
        public List<BOTransactionReport> getSpecificBranchName(string BranchName)
        {
            List<BOTransactionReport> lstrep = new List<BOTransactionReport>();

            sqlQuery = "SELECT tm.TRANS_ID AS [Transaction ID],cm.FirstName + ' ' + cm.LastName AS [Customer Name],bm.BR_NAME AS [Branch Name], " +
                        "tm.AMOUNT AS [Amount],tm.DATEOFTRANSACTION AS [Date of Transaction], tm.TRANS_DONEBY AS [Payee], tm.CLEAR_DATE AS [Transaction Cleared]" +
                        " FROM AIR.dbo.TransactionMaster1 tm INNER JOIN AIR.dbo.CustomerMaster cm ON cm.ID = tm.CUST_ID INNER JOIN air.dbo.BranchMaster bm ON " +
                        "bm.BR_ID = tm.BRANCH_ID  Where bm.BR_NAME LIKE '%" + BranchName + "%'";
            DataTable dt = dbObj.GetDataTable(sqlQuery);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //In this method, we are accessing the private method.
                lstrep.Add(lstTransactionReport(dt.Rows[i]));
            }
            return lstrep;
        }

        /// <summary>
        /// In this method, we are reterving all report based on Amount
        /// </summary>
        /// <returns></returns>
        public List<BOTransactionReport> getAllReportbasedOnAmount()
        {
            List<BOTransactionReport> lstrep = new List<BOTransactionReport>();

            sqlQuery = "SELECT tm.TRANS_ID AS [Transaction ID],cm.FirstName + ' ' + cm.LastName AS [Customer Name],bm.BR_NAME AS [Branch Name], " +
                        "tm.AMOUNT AS [Amount],tm.DATEOFTRANSACTION AS [Date of Transaction], tm.TRANS_DONEBY AS [Payee], tm.CLEAR_DATE AS [Transaction Cleared]" +
                        " FROM AIR.dbo.TransactionMaster1 tm INNER JOIN AIR.dbo.CustomerMaster cm ON cm.ID = tm.CUST_ID INNER JOIN air.dbo.BranchMaster bm ON " +
                        "bm.BR_ID = tm.BRANCH_ID ORDER BY tm.AMOUNT";
            DataTable dt = dbObj.GetDataTable(sqlQuery);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //In this method, we are accessing the private method.
                lstrep.Add(lstTransactionReport(dt.Rows[i]));
            }
            return lstrep;
        }

        /// <summary>
        /// In this method, we are reterving specific report based on Amount
        /// </summary>
        /// <param name="Amount"></param>
        /// <returns></returns>
        public List<BOTransactionReport> getSpecificAmount(decimal Amount)
        {
            List<BOTransactionReport> lstrep = new List<BOTransactionReport>();

            sqlQuery = "SELECT tm.TRANS_ID AS [Transaction ID],cm.FirstName + ' ' + cm.LastName AS [Customer Name],bm.BR_NAME AS [Branch Name]," +
                        " tm.AMOUNT AS [Amount],tm.DATEOFTRANSACTION AS [Date of Transaction], tm.TRANS_DONEBY AS [Payee], tm.CLEAR_DATE AS [Transaction Cleared]" +
                        " FROM AIR.dbo.TransactionMaster1 tm INNER JOIN AIR.dbo.CustomerMaster cm ON cm.ID = tm.CUST_ID INNER JOIN air.dbo.BranchMaster bm ON " +
                        "bm.BR_ID = tm.BRANCH_ID WHERE tm.AMOUNT LIKE '%" + Amount + "%'";
            DataTable dt = dbObj.GetDataTable(sqlQuery);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //In this method, we are accessing the private method.
                lstrep.Add(lstTransactionReport(dt.Rows[i]));
            }
            return lstrep;
        }

        /// <summary>
        /// In this method, we are reterving specific report based on Amount is greater than
        /// </summary>
        /// <param name="Amount"></param>
        /// <returns></returns>
        public List<BOTransactionReport> getAllAmountGreat(decimal Amount)
        {
            List<BOTransactionReport> lstrep = new List<BOTransactionReport>();

            sqlQuery = "SELECT tm.TRANS_ID AS [Transaction ID],cm.FirstName + ' ' + cm.LastName AS [Customer Name],bm.BR_NAME AS [Branch Name]," +
                        " tm.AMOUNT AS [Amount],tm.DATEOFTRANSACTION AS [Date of Transaction], tm.TRANS_DONEBY AS [Payee], tm.CLEAR_DATE AS [Transaction Cleared]" +
                        " FROM AIR.dbo.TransactionMaster1 tm INNER JOIN AIR.dbo.CustomerMaster cm ON cm.ID = tm.CUST_ID INNER JOIN air.dbo.BranchMaster bm ON " +
                        "bm.BR_ID = tm.BRANCH_ID WHERE tm.AMOUNT >= " + Amount ;
            DataTable dt = dbObj.GetDataTable(sqlQuery);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //In this method, we are accessing the private method.
                lstrep.Add(lstTransactionReport(dt.Rows[i]));
            }
            return lstrep;
        }

        /// <summary>
        /// In this method, we are reterving specific report based on Amount less than
        /// </summary>
        /// <param name="Amount"></param>
        /// <returns></returns>
        public List<BOTransactionReport> getSpecificAmountLess(decimal Amount)
        {
            List<BOTransactionReport> lstrep = new List<BOTransactionReport>();

            sqlQuery = "SELECT tm.TRANS_ID AS [Transaction ID],cm.FirstName + ' ' + cm.LastName AS [Customer Name],bm.BR_NAME AS [Branch Name]," +
                        " tm.AMOUNT AS [Amount],tm.DATEOFTRANSACTION AS [Date of Transaction], tm.TRANS_DONEBY AS [Payee], tm.CLEAR_DATE AS [Transaction Cleared]" +
                        " FROM AIR.dbo.TransactionMaster1 tm INNER JOIN AIR.dbo.CustomerMaster cm ON cm.ID = tm.CUST_ID INNER JOIN air.dbo.BranchMaster bm ON " +
                        "bm.BR_ID = tm.BRANCH_ID WHERE tm.AMOUNT <= " + Amount ;
            DataTable dt = dbObj.GetDataTable(sqlQuery);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //In this method, we are accessing the private method.
                lstrep.Add(lstTransactionReport(dt.Rows[i]));
            }
            return lstrep;
        }

        /// <summary>
        /// In this method, we are reterving specific report based on Amount equal to
        /// </summary>
        /// <param name="Amount"></param>
        /// <returns></returns>
        public List<BOTransactionReport> getSpecificAmountEqual(decimal Amount)
        {
            List<BOTransactionReport> lstrep = new List<BOTransactionReport>();

            sqlQuery = "SELECT tm.TRANS_ID AS [Transaction ID],cm.FirstName + ' ' + cm.LastName AS [Customer Name],bm.BR_NAME AS [Branch Name]," +
                        " tm.AMOUNT AS [Amount],tm.DATEOFTRANSACTION AS [Date of Transaction], tm.TRANS_DONEBY AS [Payee], tm.CLEAR_DATE AS [Transaction Cleared]" +
                        " FROM AIR.dbo.TransactionMaster1 tm INNER JOIN AIR.dbo.CustomerMaster cm ON cm.ID = tm.CUST_ID INNER JOIN air.dbo.BranchMaster bm ON " +
                        "bm.BR_ID = tm.BRANCH_ID WHERE tm.AMOUNT ="  + Amount ;
            DataTable dt = dbObj.GetDataTable(sqlQuery);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //In this method, we are accessing the private method.
                lstrep.Add(lstTransactionReport(dt.Rows[i]));
            }
            return lstrep;
        }

        /// <summary>
        /// This is the private method to accessing the Report values.
        /// </summary>
        /// <param name="brow"></param>
        /// <returns></returns>
        private BOTransactionReport lstTransactionReport(DataRow brow)
        {
            BOTransactionReport brp = new BOTransactionReport();
            brp.TransactionID = (int)brow["Transaction ID"];
            brp.CustomerName = (string)brow["Customer Name"];
            brp.BranchName = (string)brow["Branch Name"];
            brp.Amount = (decimal)brow["Amount"];
            brp.DateOftransaction = (DateTime)brow["Date Of Transaction"];
            brp.TransactionDoneBy = (string)brow["Payee"];
            brp.ClearDate = (DateTime)brow["Transaction Cleared"];
            return brp;
        }

        #endregion

        #region Taluk Class



        #endregion

    }
}
