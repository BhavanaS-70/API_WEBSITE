﻿using CustomerDetials.Data_Layer;
using CustomerDetials.Models;
using System.Data;
using System.Text.RegularExpressions;

namespace CustomerDetials.Business_Layer
{
    public class BLBranch
    {
        #region Delaration
        string sqlQuery = string.Empty;
        BOBranch bnh = new BOBranch();
        List<BOBranch> branch = new List<BOBranch>();
        DataLayer dbObj = new DataLayer();
        #endregion

        #region Business public methods
        /// <summary>
        /// In this method, we are reterving All Branch Details
        /// </summary>
        /// <returns></returns>
        public List<BOBranch> getAllBranchDetials()
        {
            List<BOBranch> lstBranch = new List<BOBranch>();
            sqlQuery = "select * from BranchMaster";

            DataTable dt = dbObj.GetDataTable(sqlQuery);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //In this method, we are accessing the private method.
                lstBranch.Add(BranchDetials(dt.Rows[i]));
            }
            return lstBranch;
        }

        /// <summary>
        /// In this method, we are Diplay the Single Branch Detials
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public BOBranch getSingleBranchDetail(int ID)
        {
            sqlQuery = "select * from BranchMaster where BR_ID=" + ID + "";
            DataTable dt = dbObj.GetDataTable(sqlQuery);
            
            //In this, we are checking whether the Data found or not
            if (dt.Rows.Count > 0)
            {
                //In this method, we are accessing the private method.
                return BranchDetials(dt.Rows[0]);
            }
            else
            {
                bnh.IsSuccess = false;
                bnh.Message = "Data not Found";
                bnh.statusCode = StatusCodes.Status404NotFound;
                return bnh;
            }
        }

        /// <summary>
        /// In this method, we are Insert the Single Branch Detials
        /// </summary>
        /// <param name="bnhobj"></param>
        /// <returns></returns>
        public BOBranch saveBranchDetail(BOBranch bnhobj)
        {
            //In the following line, we are fetching the Taluk Id using the BOTaluk model and the Business layer of Taluk class.
            BOTaluk tk = new BLTalukMaster().getSingleTalukDetail(bnhobj.branchAddress.TalukID);
            //In the following line, we are fetching the District Id using the BODistrict model and the Business layer of District class.
            BODistrict dst = new BLDistrict().getSingleDistrictDetail(bnhobj.branchAddress.DistrictID);

            //Declaration of Regex Expressions
            string bnkCodeExp = @"^[A-Z0-9]{4}$";
            string ifscExpressions = @"^[A-Z]{4}[0-9]{7}$";
            string pincodeExpression = @"^[1-9][0-9]{5}$";

            //validation for Bank code
            Regex rgx = new Regex(bnkCodeExp);
            if (!rgx.IsMatch(bnhobj.BranchCode))
            {
                bnhobj.IsSuccess = false;
                bnhobj.Message = "Invalid Branch Code";
                bnhobj.statusCode = StatusCodes.Status406NotAcceptable;
                return bnhobj;
            }

            //validation for Bank IFSC code
            Regex rg = new Regex(ifscExpressions);
            if (!rg.IsMatch(bnhobj.BranchIFSC))
            {
                bnhobj.IsSuccess = false;
                bnhobj.Message = "Invalid IFSC Code";
                bnhobj.statusCode = StatusCodes.Status406NotAcceptable;
                return bnhobj;
            }

            //validation for pincode
            int pincode = bnhobj.branchAddress.Pincode;
            bool pinSuccess = Regex.IsMatch(pincode.ToString(), pincodeExpression);
            if (!pinSuccess)
            {
                bnhobj.IsSuccess = false;
                bnhobj.Message = "Invalid Pincode";
                bnhobj.statusCode = StatusCodes.Status406NotAcceptable;
                return bnhobj;
            }

            //validation for Taluk ID
            if (tk == null)
            {
                bnhobj.IsSuccess = false;
                bnhobj.Message = "Invalid Taluk ID";
                bnhobj.statusCode = StatusCodes.Status406NotAcceptable;
                return bnhobj;
            }

            //validation for District ID
            if (dst == null)
            {
                bnhobj.IsSuccess = false;
                bnhobj.Message = "Invalid District ID";
                bnhobj.statusCode = StatusCodes.Status404NotFound;
                return bnhobj;
            }

            //Checking the District ID against the Taluk class of District ID
            if (bnhobj.branchAddress.DistrictID != tk.D_Id)
            {
                bnhobj.IsSuccess = false;
                bnhobj.Message = "Invalid District ID";
                bnhobj.statusCode = StatusCodes.Status406NotAcceptable;
                return bnhobj;
            }
            
            sqlQuery = "Insert into BranchMaster values ('" +
                                    bnhobj.BranchName + "', '" +
                                    bnhobj.BranchCode + "', '" +
                                    bnhobj.BranchIFSC + "', '" +
                                    bnhobj.branchAddress.Area + "', '" +
                                    bnhobj.branchAddress.Street + "', '" +
                                    bnhobj.branchAddress.LandMark+"',"+
                                    bnhobj.branchAddress.Pincode + "," +
                                    bnhobj.branchAddress.TalukID + "," +
                                    bnhobj.branchAddress.DistrictID + "," +
                                    bnhobj.BankID +  ")";
            int result = dbObj.ExecuteOnlyQuery(sqlQuery);

            //In this, we are checking whether the insertion was successful or failed
            if (result > 0)
            {
                bnhobj.IsSuccess = true;
                bnhobj.Message = "Inserted Successfully";
                bnhobj.statusCode = StatusCodes.Status200OK;
                return bnhobj;
            }
            else
            {
                bnhobj.IsSuccess = false;
                bnhobj.Message = "Inserted Failure";
                bnhobj.statusCode = StatusCodes.Status500InternalServerError;
                return bnhobj;
            }
        }

        /// <summary>
        /// In this method, We are Updating the Branch detial
        /// </summary>
        /// <param name="cusobj"></param>
        /// <returns></returns>
        public BOBranch UpdateBranchDetail(BOBranch Obj)
        {
            //In the following line, we are fetching the Taluk Id using the BOTaluk model and the Business layer of Taluk class.
            BOTaluk tk = new BLTalukMaster().getSingleTalukDetail(Obj.branchAddress.TalukID);
            //In the following line, we are fetching the District Id using the BODistrict model and the Business layer of District class.
            BODistrict dst = new BLDistrict().getSingleDistrictDetail(Obj.branchAddress.DistrictID);

            //Declaration of Regex Expressions
            string bnkCodeExp = @"^[A-Z0-9]{4}$";
            string ifscExpressions = @"^[A-Z]{4}[0-9]{7}$";
            string pincodeExpression = @"^[1-9][0-9]{5}$";

            //validation for Bank IFSC code
            Regex rg = new Regex(ifscExpressions);
            if (!rg.IsMatch(Obj.BranchIFSC))
            {
                Obj.IsSuccess = false;
                Obj.Message = "Invalid IFSC Code";
                Obj.statusCode = StatusCodes.Status406NotAcceptable;
                return Obj;
            }

            //validation for Bank code
            Regex rgx = new Regex(bnkCodeExp);
            if (!rgx.IsMatch(Obj.BranchCode))
            {
                Obj.IsSuccess = false;
                Obj.Message = "Invalid Branch Code";
                Obj.statusCode = StatusCodes.Status406NotAcceptable;
                return Obj;
            }

            //validation for pincode
            int pincode = Obj.branchAddress.Pincode;
            bool pinSuccess = Regex.IsMatch(pincode.ToString(), pincodeExpression);
            if (!pinSuccess)
            {
                Obj.IsSuccess = false;
                Obj.Message = "Invalid Pincode";
                Obj.statusCode = StatusCodes.Status406NotAcceptable;
                return Obj;
            }

            //validation for Taluk ID
            if (tk == null)
            {
                Obj.IsSuccess = false;
                Obj.Message = "Invalid Taluk ID";
                Obj.statusCode = StatusCodes.Status406NotAcceptable;
                return Obj;
            }

            //validation for District ID
            if (dst == null)
            {
                Obj.IsSuccess = false;
                Obj.Message = "Invalid District ID";
                Obj.statusCode = StatusCodes.Status404NotFound;
                return Obj;
            }

            //Checking the District ID against the Taluk class of District ID
            if (Obj.branchAddress.DistrictID != tk.D_Id)
            {
                Obj.IsSuccess = false;
                Obj.Message = "Invalid District ID";
                Obj.statusCode = StatusCodes.Status406NotAcceptable;
                return Obj;
            }

            sqlQuery = "UPDATE BranchMaster SET BR_Name = '" + Obj.BranchName + "', BR_Code = '" + Obj.BranchCode + "', BR_IFSC = '" + Obj.BranchIFSC +
                                "', BR_Area = '" + Obj.branchAddress.Area + "', BR_Street = '" + Obj.branchAddress.Street + "',BR_LandMark = '" + Obj.branchAddress.LandMark + "', BR_Pincode = " + Obj.branchAddress.Pincode +
                                ", BR_TalukId = " + Obj.branchAddress.TalukID + ", BR_DistrictID = " + Obj.branchAddress.DistrictID + ", BankID = " + Obj.BankID + " WHERE BR_ID = " + Obj.ID + "";
            DataLayer dt = new DataLayer();
            int result = dt.ExecuteOnlyQuery(sqlQuery);

            //In this, we are checking whether the Updation was successful or failed
            if (result > 0)
            {
                Obj.IsSuccess = true;
                Obj.Message = "Updated Successfully";
                Obj.statusCode = StatusCodes.Status200OK;
                return Obj;
            }
            else
            {
                Obj.IsSuccess = false;
                Obj.Message = "Updated Failure";
                Obj.statusCode = StatusCodes.Status500InternalServerError;
                return Obj;
            }
        }

        /// <summary>
        /// In this method, we are Deleting a Single Branch Details
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public bool DeleteBranchDetail(int ID)
        {
            sqlQuery = "delete from BranchMaster where BR_ID='" + ID + "'";
            int count = dbObj.ExecuteOnlyQuery(sqlQuery);
            return (count > 0 ? true : false);
        }

        /// <summary>
        /// This is the public method to accessing the Branch values.
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        public BOBranch BranchDetials(DataRow row)
        {

            BOBranch brhObj = new BOBranch();
            Address branchAdd = new Address();

            branchAdd.Area = (string)row["BR_Area"];
            branchAdd.Street = (string)row["BR_Street"];
            branchAdd.LandMark = (string)row["BR_LandMark"];
            branchAdd.Pincode = (int)row["BR_Pincode"];
            branchAdd.TalukID = (int)row["BR_TalukID"];
            branchAdd.DistrictID = (int)row["BR_DistrictID"];


            brhObj.ID = (int)row["BR_Id"];
            brhObj.BranchName = (string)row["BR_Name"];
            brhObj.BranchCode = (string)row["BR_Code"];
            brhObj.BranchIFSC = (string)row["BR_IFSC"];
            brhObj.branchAddress = branchAdd;
            brhObj.BankID = (int)row["BankID"];

            return brhObj;
        }

        /*private bool validation(BOBranch bnh)
        {
            string bnkCodeExp = @"^[A-Z0-9]{4}$";
            string ifscExpressions = @"^[A-Z]{4}[0-9]{7}$";
            string pincodeExpression = @"^[1-9][0-9]{5}$";
            Taluk tk = new BLTalukMaster().getSingleTalukDetail(bnh.ID);
            BODistrict dst = new BLDistrict().getSingleDistrictDetail(bnh.ID);

            //validation for Bank IFSC code
            Regex rg = new Regex(ifscExpressions);
            if (!rg.IsMatch(bnh.BranchIFSC))
            {
                bnh.IsSuccess = false;
                bnh.Message = "Invalid IFSC Code";
                bnh.statusCode = StatusCodes.Status406NotAcceptable;
                return true;
            }

            //validation for Bank code
            Regex rgx = new Regex(bnkCodeExp);
            if (!rgx.IsMatch(bnh.BranchCode))
            {
                bnh.IsSuccess = false;
                bnh.Message = "Invalid Branch Code";
                bnh.statusCode = StatusCodes.Status406NotAcceptable;
                return true;
            }

            //validation for pincode
            int pincode = bnh.branchAddress.Pincode;
            bool pinSuccess = Regex.IsMatch(pincode.ToString(), pincodeExpression);
            if (!pinSuccess)
            {
                bnh.IsSuccess = false;
                bnh.Message = "Invalid Pincode";
                bnh.statusCode = StatusCodes.Status406NotAcceptable;
                return true;
            }

            //validation for Taluk ID
            if (tk == null)
            {
                bnh.IsSuccess = false;
                bnh.Message = "Invalid Taluk ID";
                bnh.statusCode = StatusCodes.Status406NotAcceptable;
                return true;
            }

            //validation for District ID
            if (dst == null)
            {
                bnh.IsSuccess = false;
                bnh.Message = "Invalid District ID";
                bnh.statusCode = StatusCodes.Status404NotFound;
                return true;
            }

            if (bnh.branchAddress.DistrictID != tk.D_Id)
            {
                bnh.IsSuccess = false;
                bnh.Message = "Invalid District ID";
                bnh.statusCode = StatusCodes.Status406NotAcceptable;
                return true;
            }
            return true;
        }*/
        #endregion
    }
}
