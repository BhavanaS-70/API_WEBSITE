﻿using CustomeDetials.Models;
using CustomerDetials.Data_Layer;
using System.Collections.Immutable;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace CustomeDetials.Business_Layer
{
    public class BLTransaction
    {
        #region Declaration
        string sqlQuery = string.Empty;
        BOTransaction trans = new BOTransaction();
        DataLayer dbObj = new DataLayer();
        #endregion

        /// <summary>
        /// In this method, we are retrieving all transactions.
        /// </summary>
        /// <returns></returns>
        public List<BOTransaction> getAllTransaction()
        {
            List<BOTransaction> bOTransactions = new List<BOTransaction>();
            sqlQuery = "select * from transactionMaster1";
            DataTable dt = dbObj.GetDataTable(sqlQuery);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //In this method, we are accessing the private method.
                bOTransactions.Add(Transaction(dt.Rows[i]));
            }
            return bOTransactions;

        }

        /// <summary>
        /// In this method, we are retrieving Single transactions based on ID.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public BOTransaction getSingleTransaction(int id)
        {
            BOTransaction bTx = new BOTransaction();
            sqlQuery = "select * from transactionMaster1 where TRANS_ID = " + id + "";
            DataTable dt = dbObj.GetDataTable(sqlQuery);

            //In this, we are checking whether the Data found or not
            if (dt.Rows.Count > 0)
            {
                //In this method, we are accessing the private method.
                return Transaction(dt.Rows[0]);
            }
            else
            {
                trans = new BOTransaction();
                trans.IsSuccess = false;
                trans.Message = "Data not found";
                trans.statusCode = StatusCodes.Status404NotFound;
            }
            return trans;
        }

        /// <summary>
        /// In this method, we are Inserting teh values for transactions.
        /// </summary>
        /// <param name="bt"></param>
        /// <returns></returns>
        public BOTransaction saveTransaction(BOTransaction bt)
        {
            //valiation for customer ID
            if (bt.CustID == 0)
            {
                bt.IsSuccess = false;
                bt.Message = "Invalid Cutomer ID";
                bt.statusCode = StatusCodes.Status406NotAcceptable;
                return bt;
            }
            
            //Validation for Branch ID
            if (bt.BranchID == 0)
            {
                bt.IsSuccess = false;
                bt.Message = "Invalid Branch ID";
                bt.statusCode = StatusCodes.Status406NotAcceptable;
                return bt;
            }
            
            //validation for amount should be greater than 0 and less than 2000000
            if (bt.Amount > 0 || bt.Amount<2000000)
            {
                bt.IsSuccess = false;
                bt.Message = "Enter valid Amount";
                bt.statusCode = StatusCodes.Status406NotAcceptable;
                return bt;
            }
            
            //validation for Date of Transaction should be less than or equal to current date and time
            if (bt.DateOfTransaction >= DateTime.Now)
            {
                bt.IsSuccess = false;
                bt.Message = "Please Enter the current date and time " + bt.DateOfTransaction;
                bt.statusCode = StatusCodes.Status406NotAcceptable;
                return bt;
            }
            
            //validation for Transaction done by
            if (bt.TrasacionDoneBy == null)
            {
                bt.IsSuccess = false;
                bt.Message = "Please, Insert the name of the person who conducted the transaction";
                bt.statusCode = StatusCodes.Status406NotAcceptable;
                return bt;
            }

            //validating the clear date should be less than or equal to current date and time or clear date should be greater than date oftransaction
            if (bt.ClearDate >= DateTime.Now || bt.ClearDate < bt.DateOfTransaction)
            {
                bt.IsSuccess = false;
                bt.Message = "Invalid transaction: ClearDate should be later than both the current date and time and the DateOfTransaction.";
                bt.statusCode = StatusCodes.Status406NotAcceptable;
                return bt;
            }

            sqlQuery = "Insert into transactionMaster1 values (" +
                                bt.CustID + "," +
                                bt.BranchID + "," +
                                bt.Amount + ",'" +
                                bt.DateOfTransaction + "','" +
                                bt.TrasacionDoneBy + "','" +
                                bt.ClearDate + "')";
            int count = dbObj.ExecuteOnlyQuery(sqlQuery);

            //In this, we are checking whether the insertion was successful or failed
            if (count > 0)
            {
                trans.IsSuccess = true;
                trans.Message = "Inserted Succesfully";
                trans.statusCode = StatusCodes.Status200OK;
                return trans;
            }
            else
            {
                trans.IsSuccess = false;
                trans.Message = "Inserted Failure";
                trans.statusCode = StatusCodes.Status500InternalServerError;
                return trans;
            }
        }

        /// <summary>
        /// In this method, We are Updating the Transaction detial
        /// </summary>
        /// <param name="bt"></param>
        /// <returns></returns>
        public BOTransaction updateTransaction(BOTransaction bt)
        {
            //valiation for customer ID
            if (bt.CustID == 0)
            {
                bt.IsSuccess = false;
                bt.Message = "Invalid Cutomer ID";
                bt.statusCode = StatusCodes.Status406NotAcceptable;
                return bt;
            }

            //Validation for Branch ID
            if (bt.BranchID == 0)
            {
                bt.IsSuccess = false;
                bt.Message = "Invalid Branch ID";
                bt.statusCode = StatusCodes.Status406NotAcceptable;
                return bt;
            }

            //validation for amount should be greater than 0 and less than 2000000
            if (bt.Amount > 0 || bt.Amount < 2000000)
            {
                bt.IsSuccess = false;
                bt.Message = "Enter valid Amount";
                bt.statusCode = StatusCodes.Status406NotAcceptable;
                return bt;
            }

            //validation for Date of Transaction should be less than or equal to current date and time
            if (bt.DateOfTransaction >= DateTime.Now)
            {
                bt.IsSuccess = false;
                bt.Message = "Please Enter the current date and time " + bt.DateOfTransaction;
                bt.statusCode = StatusCodes.Status406NotAcceptable;
                return bt;
            }

            //validation for Transaction done by
            if (bt.TrasacionDoneBy == null)
            {
                bt.IsSuccess = false;
                bt.Message = "Please enter the name of the person who conducted the transaction";
                bt.statusCode = StatusCodes.Status406NotAcceptable;
                return bt;
            }

            //validating the clear date should be less than or equal to current date and time or clear date should be greater than date oftransaction
            if (bt.ClearDate >= DateTime.Now || bt.ClearDate < bt.DateOfTransaction)
            {
                bt.IsSuccess = false;
                bt.Message = "Invalid transaction: ClearDate should be later than both the current date and time and the DateOfTransaction.";
                bt.statusCode = StatusCodes.Status406NotAcceptable;
                return bt;
            }

            sqlQuery = "Update transactionMaster1 set cust_id="+bt.CustID+",branch_id="+bt.BranchID+ ",Amount="+
                            bt.Amount+ ",DATEOFTRANSACTION='" + bt.DateOfTransaction + "',TRANS_DONEBY='" +
                            bt.TrasacionDoneBy+"',Clear_date='"+bt.ClearDate+ "' WHERE TRANS_ID = " + bt.Id + "";
            DataLayer dataLayer = new DataLayer();
            int result = dataLayer.ExecuteOnlyQuery(sqlQuery);

            //In this, we are checking whether the Updation was successful or failed
            if (result > 0)
            {
                trans.IsSuccess = true;
                trans.Message = "Updated Successfully";
                trans.statusCode = StatusCodes.Status200OK;
                return trans;
            }
            else
            {
                trans.IsSuccess = false;
                trans.Message = "Update Failure";
                trans.statusCode = StatusCodes.Status500InternalServerError;
                return trans;
            }
        }

        /// <summary>
        /// This is the private method to accessing the Transaction values.
        /// </summary>
        /// <param name="bot"></param>
        /// <returns></returns>
        public BOTransaction Transaction(DataRow bot)
        {
            BOTransaction bOTransaction = new BOTransaction();
            bOTransaction.Id = (int)bot["Trans_ID"];
            bOTransaction.CustID = (int)bot["Cust_id"];
            bOTransaction.BranchID = (int)bot["Branch_id"];
            bOTransaction.Amount = (decimal)bot["Amount"];
            bOTransaction.DateOfTransaction = (DateTime)bot["dateoftransaction"];
            bOTransaction.TrasacionDoneBy = (string)bot["Trans_doneby"];
            bOTransaction.ClearDate = (DateTime)bot["clear_date"];
            return bOTransaction;
        }
    }
}
