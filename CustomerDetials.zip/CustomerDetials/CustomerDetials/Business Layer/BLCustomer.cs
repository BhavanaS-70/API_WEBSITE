﻿using CustomeDetials.Models;
using CustomerDetials.Data_Layer;
using CustomerDetials.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Reflection;
using System.Text.RegularExpressions;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace CustomerDetials.Business_Layer
{
    public class BLCustomer
    {
        #region Delaration
        string sqlQuery = string.Empty;
        BOCustomer cus = new BOCustomer();
        List<BOCustomer> cust = new List<BOCustomer>();
        DataLayer dbObj = new DataLayer();
        #endregion

        #region Business public methods
        /// <summary>
        /// In this method, we are display All Customer Details
        /// </summary>
        /// <returns></returns>
        public List<BOCustomer> getAllCustomerDetials()
        {
            List<BOCustomer> lstCustomer = new List<BOCustomer>();
            sqlQuery = "select * from CustomerMaster";

            DataTable dt = dbObj.GetDataTable(sqlQuery);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                //In this method, we are accessing the private method.
                lstCustomer.Add(CustomerDetials(dt.Rows[i]));
            }
            return lstCustomer;
        }

        /// <summary>
        /// In this method, we are Diplay the Single Customer Detials
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public BOCustomer getSingleCustomerDetail(int ID)
        {
            BOCustomer custobj = new BOCustomer();
            sqlQuery = "select * from CustomerMaster where id=" + ID + "";
            DataTable dt = dbObj.GetDataTable(sqlQuery);

            //In this, we are checking whether the Data found or not
            if (dt.Rows.Count > 0)
            {
                //In this method, we are accessing the private method.
                return CustomerDetials(dt.Rows[0]);
            }
            else
            {
                custobj = new BOCustomer();
                custobj.IsSuccess = false;
                custobj.Message = "Data not found";
                custobj.statusCode = StatusCodes.Status400BadRequest;
            }
           return custobj;
        }

        /// <summary>
        /// In this method,We are Inserting data to a Customer table
        /// </summary>
        /// <param name="cusobj"></param>
        /// <returns></returns>
        public BOCustomer saveCustomerMasters(BOCustomer obj)
        {
            //In the following line, we are fetching the Taluk Id using the BOTaluk model and the Business layer of Taluk class.
            BOTaluk Bttl = new BLTalukMaster().getSingleTalukDetail(obj.TempAddress.TalukID);  
            BOTaluk Btpl = new BLTalukMaster().getSingleTalukDetail(obj.PermanentAddress.TalukID);
            
            //In the following line, we are fetching the District Id using the BODistrict model and the Business layer of District class.
            BODistrict Bdtl = new BLDistrict().getSingleDistrictDetail(obj.TempAddress.DistrictID);
            BODistrict Bdpl = new BLDistrict().getSingleDistrictDetail(obj.PermanentAddress.DistrictID);

            //Declaration of Regex Expressions
            string pincodeExpression = @"^[1-9][0-9]{5}$";
            string panExpressions = @"^[A-Z]{5}[0-9]{4}[A-Z]$";
            string mailExpressions = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";

            //Validation for Date of Birth
            if (obj.DOB>=DateTime.Today)
            {
                obj.IsSuccess=false;
                obj.Message = "invalid date of birth" + obj.DOB;
                obj.statusCode = StatusCodes.Status406NotAcceptable;
                return obj;
            }

            //Validation for Gender
            if (!(obj.Gender<3 && obj.Gender>=0))
            {
                obj.IsSuccess = false;
                obj.Message = "Invalid Gender, please enter between 0 to 3";
                obj.statusCode = StatusCodes.Status406NotAcceptable;
                return obj;
            }

            //validation for pincode
            int temppin= obj.TempAddress.Pincode;
            bool success = Regex.IsMatch(temppin.ToString(), pincodeExpression);
            if (!success)
            {
                obj.IsSuccess = false;
                obj.Message = "Invalid Temporary Pincode ID";
                obj.statusCode = StatusCodes.Status406NotAcceptable;
                return obj;
            }
            int perpin=obj.PermanentAddress.Pincode;
            bool successfully = Regex.IsMatch(perpin.ToString(), pincodeExpression);
            if (!successfully)
            {
                obj.IsSuccess = false;
                obj.Message = "Invalid Permanent Pincode ID";
                obj.statusCode = StatusCodes.Status406NotAcceptable;
                return obj;
            }

            //Validation for Taluk ID
            if (Bttl == null)
            {
                obj.IsSuccess = false;
                obj.Message = "Invalid Taluk ID";
                obj.statusCode = StatusCodes.Status406NotAcceptable;
                return obj;
            }

            //Validation for District ID
            if (Bdpl == null)
            {
                obj.IsSuccess = false;
                obj.Message = "Invalid District ID";
                obj.statusCode = StatusCodes.Status406NotAcceptable;
                return obj;
            }

            //Checking the temporary Taluk ID against the Taluk class of Taluk ID
            if (obj.TempAddress.TalukID != Bttl.T_Id)
            {
                obj.IsSuccess = false;
                obj.Message = "Invalid temporary Taluk ID";
                obj.statusCode = StatusCodes.Status406NotAcceptable;
                return obj;
            }

            //Checking the Permanent Taluk ID against the Taluk class of Taluk ID
            if (obj.PermanentAddress.TalukID != Btpl.T_Id)
            {
                obj.IsSuccess = false;
                obj.Message = "Invalid Permanent Taluk ID";
                obj.statusCode = StatusCodes.Status406NotAcceptable;
                return obj;
            }

            //Checking the temporary District ID against the District class of District ID
            if (obj.TempAddress.DistrictID != Bdtl.D_Id)
            {
                obj.IsSuccess = false;
                obj.Message = "Invalid temporary District ID";
                obj.statusCode = StatusCodes.Status406NotAcceptable;
                return obj;
            }

            //Checking the Permanent District ID against the District class of District ID
            if (obj.PermanentAddress.DistrictID != Bdpl.D_Id)
            {
                obj.IsSuccess = false;
                obj.Message = "Invalid permanent District ID";
                obj.statusCode = StatusCodes.Status406NotAcceptable;
                return obj;
            }

            //validation for Aadhar number using length property
            if (!(obj.AadharNumber.Length == 12))
            {
                obj.IsSuccess = false;
                obj.Message = "Invalid Aadhar Number";
                obj.statusCode = StatusCodes.Status406NotAcceptable;
                return obj;
            }

            //Validation for PAN number 
            string pan = obj.PanNumber;
            bool panFailure = Regex.IsMatch(pan,panExpressions);
            if (!panFailure)
            {
                obj.IsSuccess = false;
                obj.Message = "Invalid PAN Number";
                obj.statusCode = StatusCodes.Status406NotAcceptable;
                return obj;
            }

            //Validation for E-Mail 
            string email = obj.EmailID;
            bool emailFailure = Regex.IsMatch(email,mailExpressions);
            if (!emailFailure)
            {
                obj.IsSuccess = false;
                obj.Message = "Invalid E-Mail ID";
                obj.statusCode = StatusCodes.Status406NotAcceptable;
                return obj;
            }

            sqlQuery = "INSERT INTO CustomerMaster values('" + obj.FirstName + "','" + obj.MiddleName + "','" + obj.LastName + "','" + obj.FatherName + "','" + obj.MotherName + "','" + obj.DOB + "'," + obj.Gender + " , '" +
                            obj.TempAddress.Area + "','" + obj.TempAddress.Street + "','" + obj.TempAddress.Pincode + "'," + obj.TempAddress.TalukID + "," + obj.TempAddress.DistrictID + ", " +
                            "'" + obj.PermanentAddress.Area + "','" + obj.PermanentAddress.Street + "','" + obj.PermanentAddress.Pincode + "'," + obj.PermanentAddress.TalukID + "," + obj.PermanentAddress.DistrictID + ", " +
                            "'" + obj.MobileNumber + "','" + obj.AadharNumber + "','" + obj.PanNumber.ToUpper() + "','" + obj.EmailID.ToLower() + "','"+obj.TempAddress.LandMark+"','"+obj.PermanentAddress.LandMark+"')";
            int count = dbObj.ExecuteOnlyQuery(sqlQuery);

            //In this, we are checking whether the insertion was successful or failed
            if (count > 0)
            {
                obj.IsSuccess = true;
                obj.Message = "Inserted Successfully";
                obj.statusCode = 200;
                return obj;
            }
            else
            {
                obj.IsSuccess = false;
                obj.Message = "Inserted Failure";
                obj.statusCode = StatusCodes.Status500InternalServerError;
                return obj;
            }
        }
        
        /// <summary>
        /// In this method, We are Updating the customer detial
        /// </summary>
        /// <param name="cusobj"></param>
        /// <returns></returns>
        public BOCustomer UpdateCustomerDetail(BOCustomer Obj)
        {
            //In the following line, we are fetching the Taluk Id using the BOTaluk model and the Business layer of Taluk class.
            BOTaluk Bttl = new BLTalukMaster().getSingleTalukDetail(Obj.TempAddress.TalukID);
            BOTaluk Btpl = new BLTalukMaster().getSingleTalukDetail(Obj.PermanentAddress.TalukID);

            //In the following line, we are fetching the District Id using the BODistrict model and the Business layer of District class.
            BODistrict Bdtl = new BLDistrict().getSingleDistrictDetail(Obj.TempAddress.DistrictID);
            BODistrict Bdpl = new BLDistrict().getSingleDistrictDetail(Obj.PermanentAddress.DistrictID);

            //Declaration of Regex Expressions
            string pincodeExpression = @"^[1-9][0-9]{5}$";
            string panExpressions = @"^[A-Z]{5}[0-9]{4}[A-Z]$";
            string mailExpressions = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";

            //Validation for Date of Birth
            if (Obj.DOB >= DateTime.Today)
            {
                Obj.IsSuccess = false;
                Obj.Message = "invalid date of birth" + Obj.DOB;
                Obj.statusCode = StatusCodes.Status406NotAcceptable;
                return Obj;
            }

            //Validation for Gender
            if (!(Obj.Gender < 3 && Obj.Gender >= 0))
            {
                Obj.IsSuccess = false;
                Obj.Message = "Invalid Gender, please enter between 0 to 3";
                Obj.statusCode = StatusCodes.Status406NotAcceptable;
                return Obj;
            }

            //validation for pincode
            int temppin = Obj.TempAddress.Pincode;
            bool success = Regex.IsMatch(temppin.ToString(), pincodeExpression);
            if (!success)
            {
                Obj.IsSuccess = false;
                Obj.Message = "Invalid Temporary Pincode ID";
                Obj.statusCode = StatusCodes.Status406NotAcceptable;
                return Obj;
            }
            int perpin = Obj.PermanentAddress.Pincode;
            bool successfully = Regex.IsMatch(perpin.ToString(), pincodeExpression);
            if (!successfully)
            {
                Obj.IsSuccess = false;
                Obj.Message = "Invalid Permanent Pincode ID";
                Obj.statusCode = StatusCodes.Status406NotAcceptable;
                return Obj;
            }

            //Validation for Taluk ID
            if (Bttl == null)
            {
                Obj.IsSuccess = false;
                Obj.Message = "Invalid Taluk ID";
                Obj.statusCode = StatusCodes.Status406NotAcceptable;
                return Obj;
            }

            //Validation for District ID
            if (Bdpl == null)
            {
                Obj.IsSuccess = false;
                Obj.Message = "Invalid District ID";
                Obj.statusCode = StatusCodes.Status406NotAcceptable;
                return Obj;
            }

            //Checking the temporary Taluk ID against the Taluk class of Taluk ID
            if (Obj.TempAddress.TalukID != Bttl.T_Id)
            {
                Obj.IsSuccess = false;
                Obj.Message = "Invalid temporary Taluk ID";
                Obj.statusCode = StatusCodes.Status406NotAcceptable;
                return Obj;
            }

            //Checking the Permanent Taluk ID against the Taluk class of Taluk ID
            if (Obj.PermanentAddress.TalukID != Btpl.T_Id)
            {
                Obj.IsSuccess = false;
                Obj.Message = "Invalid Permanent Taluk ID";
                Obj.statusCode = StatusCodes.Status406NotAcceptable;
                return Obj;
            }

            //Checking the temporary District ID against the District class of District ID
            if (Obj.TempAddress.DistrictID != Bdtl.D_Id)
            {
                Obj.IsSuccess = false;
                Obj.Message = "Invalid temporary District ID";
                Obj.statusCode = StatusCodes.Status406NotAcceptable;
                return Obj;
            }

            //Checking the Permanent District ID against the District class of District ID
            if (Obj.PermanentAddress.DistrictID != Bdpl.D_Id)
            {
                Obj.IsSuccess = false;
                Obj.Message = "Invalid permanent District ID";
                Obj.statusCode = StatusCodes.Status406NotAcceptable;
                return Obj;
            }

            //validation for Aadhar number
            if (!(Obj.AadharNumber.Length == 12))
            {
                Obj.IsSuccess = false;
                Obj.Message = "Invalid Aadhar Number";
                Obj.statusCode = StatusCodes.Status406NotAcceptable;
                return Obj;
            }

            //Validation for PAN number 
            string pan = Obj.PanNumber;
            bool panFailure = Regex.IsMatch(pan, panExpressions);
            if (!panFailure)
            {
                Obj.IsSuccess = false;
                Obj.Message = "Invalid PAN Number";
                Obj.statusCode = StatusCodes.Status406NotAcceptable;
                return Obj;
            }

            //Validation for E-Mail 
            string email = Obj.EmailID;
            bool emailFailure = Regex.IsMatch(email, mailExpressions);
            if (!emailFailure)
            {
                Obj.IsSuccess = false;
                Obj.Message = "Invalid E-Mail ID";
                Obj.statusCode = StatusCodes.Status406NotAcceptable;
                return Obj;
            }
            
            DateTime dateOnly = Obj.DOB;
            sqlQuery = "UPDATE CustomerMaster SET FirstName = '" + 
                                Obj.FirstName + "', MiddleName = '" + 
                                Obj.MiddleName + "', LastName = '" + 
                                Obj.LastName + "', FatherName = '" + 
                                Obj.FatherName + "', MotherName = '" + 
                                Obj.MotherName + "', DOB = '" + 
                                dateOnly + "', Gender = " + 
                                Obj.Gender + ", TempArea = '" + 
                                Obj.TempAddress.Area + "', TempStreet = '" + 
                                Obj.TempAddress.Street + "',TempLandMark = '" + 
                                Obj.TempAddress.LandMark + "', TempPincode = " + 
                                Obj.TempAddress.Pincode +", TempTalukId = " + 
                                Obj.TempAddress.TalukID + ", TempDistrictID = " + 
                                Obj.TempAddress.DistrictID + ", PArea = '" + 
                                Obj.PermanentAddress.Area +"', PStreet = '" + 
                                Obj.PermanentAddress.Street + "',PLandMark = '" + 
                                Obj.PermanentAddress.LandMark + "', PPincode = " + 
                                Obj.PermanentAddress.Pincode + ", PTalukId = " + 
                                Obj.PermanentAddress.TalukID +", PDistrictID = " + 
                                Obj.PermanentAddress.DistrictID + ", MobileNumber = '" + 
                                Obj.MobileNumber + "', AadharNumber = '" + 
                                Obj.AadharNumber +"', PanNumber = '" + 
                                Obj.PanNumber + "', EmailID = '" + 
                                Obj.EmailID + "' WHERE ID = " + Obj.ID+"";
            DataLayer dt = new DataLayer();
            int result = dt.ExecuteOnlyQuery(sqlQuery);

            //In this, we are checking whether the Updation was successful or failed
            if (result > 0)
            {
                Obj.IsSuccess = true;
                Obj.Message = "Updated Successfully";
                Obj.statusCode = StatusCodes.Status200OK;
                return Obj;
            }
            else
            {
                Obj.IsSuccess = false;
                Obj.Message = "Updated Failure";
                Obj.statusCode = StatusCodes.Status500InternalServerError;
                return Obj;
            }
        }
        
        /// <summary>
        /// In this method, we are Deleting a Single Customer Details
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        public bool DeleteCusomerDetail(int ID)
        {
            sqlQuery = "delete from CustomerMaster where ID='" + ID + "'";
            int count = dbObj.ExecuteOnlyQuery(sqlQuery);
            return (count > 0 ? true : false);
        }

        /// <summary>
        /// This is the private method to accessing the customer values.
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        private BOCustomer CustomerDetials(DataRow row)
        {

            BOCustomer custObj = new BOCustomer();
            Address TempAddObj = new Address();
            Address perAddObj = new Address();

            perAddObj.Area = (string)row["Parea"];
            perAddObj.Street = (string)row["PStreet"];
            perAddObj.Pincode = (int)row["PPincode"];
            perAddObj.TalukID = (int)row["PTalukID"];
            perAddObj.DistrictID = (int)row["PTalukID"];
            //perAddObj.LandMark = (string)row["LandMark"];

            TempAddObj.Area = (string)row["TempArea"];
            TempAddObj.Street = (string)row["TempStreet"];
            TempAddObj.Pincode = (int)row["TempPincode"];
            TempAddObj.TalukID = (int)row["TempTalukID"];
            TempAddObj.DistrictID = (int)row["TempDistrictID"];
            //TempAddObj.LandMark = (string)row["LandMark"];

            custObj.ID = (int)row["Id"];
            custObj.FirstName = (string)row["FirstName"];
            custObj.MiddleName = Convert.ToString(row["MiddleName"]);
            custObj.LastName = (string)row["LastName"];
            custObj.FatherName = (string)row["FatherName"];
            custObj.MotherName = (string)row["MotherName"];
            custObj.DOB = (DateTime)row["DOB"];
            custObj.Gender = (int)row["Gender"];
            custObj.PermanentAddress = perAddObj;
            custObj.TempAddress = TempAddObj;
            custObj.MobileNumber = (string)row["MobileNumber"];
            custObj.AadharNumber = (string)row["AadharNumber"];
            custObj.PanNumber = (string)row["PanNumber"];
            custObj.EmailID = (string)row["EmailID"];
            TempAddObj.LandMark = Convert.ToString(row["TempLandMark"]);
            perAddObj.LandMark = Convert.ToString(row["PLandMark"]);

            return custObj;
        }
            #endregion
    }
}
